# 🚀 Flaskey SetDev

> Create modern Flask projects instantly with a single command.

---

## ✨ Features

* ⚡ One-command project creation
* 🎨 Modern Bootstrap UI (like React/Next.js feel)
* 📦 Automatic virtual environment setup
* 🔧 Auto dependency installation
* 🧱 Clean project structure
* 🖥️ Beginner-friendly

---

## 📦 Installation

```bash
pip install flaskey-setdev
```

---

## ⚡ Usage

Create a new Flask project:

```bash
create-project flask myapp
```

---

## 📁 Project Structure

After running the command, you’ll get:

```
myapp/
├── app.py
├── requirements.txt
├── templates/
│   └── index.html
├── static/
│   └── style.css
├── venv/
```

---

## 🚀 Run Your Project

```bash
cd myapp
venv\Scripts\activate   # On Windows
python app.py
```

Then open:

```
http://127.0.0.1:5000
```

---

## 🎨 UI Preview

* Modern landing page
* Navbar + Hero section
* Buttons + responsive layout

---

## 🛠️ Troubleshooting

### ❌ Command not found

Add this to your PATH:

```
C:\Users\<YourUsername>\AppData\Roaming\Python\PythonXX\Scripts
```

Restart terminal after adding.

---

### ❌ PowerShell execution error

Run:

```powershell
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## 💡 Requirements

* Python 3.7+
* pip installed

---

## 🔥 Future Features

* FastAPI project generator
* Django template support
* Interactive CLI mode
* Auto-open browser
* More UI templates

---

## 👨‍💻 Author

**Samarth Patil**

---

## ⭐ Support

If you like this project, give it a ⭐ on GitHub!

---

## 📢 Contributing

Feel free to fork, improve, and submit pull requests.

---

## 🧠 Why Flaskey?

Flaskey helps beginners and developers quickly start projects
without wasting time on setup — just create and build 🚀
